flatpak install --system com.heroicgameslauncher.hgl -y
flatpak install --system com.mattjakeman.ExtensionManager -y
flatpak install --system com.spotify.Client -y
flatpak install --system com.vysp3r.ProtonPlus -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
